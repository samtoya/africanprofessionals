/* <![CDATA[ */
(function($){
    
    "use strict";
    
    $(document).ready(function(){
        
        /* Helper Functions
        ================================================== */
        function create_id() {
             return '-' + Math.random().toString(36).substr(2, 9);
        }
                
        /* FitVid
        ================================================== */
        $(".ut-video").fitVids();
        
        
        /* United Video Player
        ================================================== */
        function ut_load_video_player(url, uniqueID, $parent, callback){
                
            if( !url ) {
                return;
            }
                        
            var ajaxURL = utShortcode.ajaxurl,
                $video = $('<div id="ut-video'+uniqueID+'"></div>'),
                $caption = $parent.find('.ut-video-caption-text');            
            
            $.ajax({
              
              type: 'POST',
              url: ajaxURL,
              data: {"action": "ut_get_video_player", "video" : url },
              success: function(response) {                  
                  
                  $video.html(response).fitVids();                      
                  $parent.html( $video.append($caption) );
                  
                  return false;
                                   
              },
              complete : function() {
                                
                  if (callback && typeof(callback) === "function") {   
                      callback();  
                  }
                        
              }
                    
            });
        
        }
        
        /* Video Testimonials Player Call ( Lightbox )
        ================================================== */        
        function ut_load_video_player_lightbox( url, uniqueID, callback ){
            
            if( !url ) {
                return;
            }
                        
            var ajaxURL = utShortcode.ajaxurl;            
            
            $.ajax({
              
              type: 'POST',
              url: ajaxURL,
              data: {"action": "ut_get_video_player", "video" : url },
              success: function(response) {                  
                  $('#ut-video-testimonial'+uniqueID).hide().html(response).fitVids().show("fast");
                  return false;                  
              },
              complete : function() {
                                
                  if (callback && typeof(callback) === "function") {   
                      callback();  
                  }
                        
              }
                    
            });
        
        }
        
        function create_unique_prettyphoto(url,$testimonial) {
            
            if( !url ) {
                return;
            }
            
            var uniqueID = create_id(),
                div = '<div id="ut-video-testimonial'+uniqueID+'"></div>';
            
            $testimonial.prettyPhoto({
                custom_markup: div,
                allow_resize: true,
                social_tools: '',
                changepicturecallback: function(){ 
                    ut_load_video_player_lightbox(url, uniqueID, function() { 
                    
                    }); 
                }
            });
        
        }
        
        $(document).on('click', '.ut-load-video', function(event) {        
                
            var url = $(this).data('video'),
                uniqueID = create_id(),
                $parent = $(this).parent('.ut-video-caption'),
                $loader = $parent.next('.ut-video-loading');
            
            $loader.fadeIn();
                
            ut_load_video_player(url, uniqueID, $parent, function() {
                $loader.fadeOut();
            });
            
            event.preventDefault();                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
        });
        
        $(".ut-load-vtestimonial").each(function(){
            
            var url = $(this).find('div').html();                     
            create_unique_prettyphoto(url,$(this));
         
        });
        
        
        /* Milestone Counter - animate when visible on load
        ================================================== */        
        $('.ut-counter').appear();
        
        $(document.body).on('appear', '.ut-counter', function() {
                                    
            var counter = $(this).data('counter');
            
            if ( !$(this).hasClass('ut-already-counted') ) {
                
                $(this).addClass('ut-already-counted');
                                        
                $(this).find('.ut-count').countTo({
                    from: 0,
                    to: counter,
                    speed: 2000,
                    refreshInterval: 100
                });                
                    
            }
            
        });    
        
        /* Element Effects
        ================================================== */
        $('.ut-animate-element').appear();
        
        $(document.body).on('appear', '.ut-animate-element', function() {
            
            var $this = $(this);
            
            if( $this.hasClass('ut-animation-complete') ) {
                return;
            }
                        
            var effect = $this.data('effect');
            
            if( $this.data('animation-duration') ) {
                
                $this.css('animation-duration', $this.data('animation-duration') );
                
            }
            
            $this.delay( $this.data('delay') ).queue( function() {
                                
                $this.css('opacity','1').addClass( effect ).dequeue();
                
            });
            
                        
        });
        
        $(document.body).on('disappear', '.ut-animate-element', function() {
            
            var $this  = $(this),
                effect = $this.data('effect');
                        
            if( $this.data('animateonce') === 'no' ) {
                
                $this.removeClass( effect ).css('opacity','0').dequeue();                     
            
            } else {
                
                $this.addClass('ut-animation-complete');
            
            }
                        
        });
        
        /* Animate Image
        ================================================== */
        $('.ut-animate-image').appear();
        
        $(document.body).on('appear', '.ut-animate-image', function() {
            
            var $this = $(this);
            
            if( $this.hasClass('ut-animation-complete') ) {
                return;
            }
                                    
            var effect = $this.data('effect');
            
            if( $this.data('animation-duration') ) {
                
                $this.css('animation-duration', $this.data('animation-duration') );
                
            }
                
            $this.delay( $this.data('delay') ).queue( function() {
                                
                $this.css('opacity','1').addClass( effect ).dequeue();
                
            });
                       
        });
                
        $(document.body).on('disappear', '.ut-animate-image', function() {
            
            var $this  = $(this),
                effect = $this.data('effect');
                        
            if( $this.data('animateonce') === 'no' ) {
                
                $this.removeClass( effect ).css('opacity','0').dequeue();                   
            
            } else {
                
                $this.addClass('ut-animation-complete');
            
            }
                        
        });
                        
        /* Run Site Effect Animation
        ================================================== */
        $(".ut-counter, .ut-skill-active").each( function( i, el ) {
            
            var el = $(el),
                effecttype = el.data('effecttype');
            
            if( effecttype === 'image' ) {
                
                var effect = el.data('effect');
                
                if ( el.visible(true) && !el.hasClass( effect ) ) {
                    
                    el.addClass( effect ); 
                  
                }  else if( !el.visible(true) ) {
              
                    el.removeClass( effect );
                  
                }
                
            }
            
            if( effecttype === 'skillbar' ) {
                
                var bar_width = el.data('width');
        
                if ( el.visible(true) && !el.hasClass('ut-already-visible') ) {
                    
                    el.addClass("ut-already-visible");
                    el.stop(true, true).animate({width : bar_width+"%"} , 1000 );
                
                } else if( !el.visible(true) ) {
              
                    el.removeClass("ut-already-visible");
                    el.css("width" , 0);
                  
                }
                
            }
            
            if( effecttype === 'counter') {
            
                var counter = el.data('counter');
                
                if ( el.visible(true) && !$(el).hasClass('ut-already-counted') ) {
                    
                    el.addClass('ut-already-counted');
                    
                    el.find('.ut-count').countTo({
                        from: 0,
                        to: counter,
                        speed: 2000,
                        refreshInterval: 100
                    });
                  
                }
            
            }
            
        });
                
        /* Skillbar
        ================================================== */
        $(".ut-skill-active").each(function(i, el){
            
            var el = $(el),
                bar_width = el.data('width');
            
            if ( el.visible(true) && !el.hasClass('ut-already-visible') ) {
                
                if( el.hasClass('ut-skill-progress-thin') ) {
                    
                    el.stop(true, true).width(bar_width + "%");
                    
                } else {
                    
                    el.stop(true, true).animate({width : bar_width+"%"} , 1000 );
                    
                }
                
                el.addClass('ut-already-visible');
            
            }
                
        });
        
        $('.ut-skill-active').appear();
        
        $(document.body).on('appear', '.ut-skill-active', function() {
            
            var $this     = $(this),
                bar_width = $this.data('width');
                    
                if( !$this.hasClass('ut-already-visible') ) {
                    
                    if(  $this.hasClass('ut-skill-progress-thin') ) {
                        
                        $this.addClass("ut-already-visible").width(bar_width + "%");
                        
                    } else {                    
                    
                        $this.addClass("ut-already-visible").stop(true, true).animate({width : bar_width+"%"} , 1000 );
                    
                    }
                
                }            
            
                        
        });
        
        $(document.body).on('disappear', '.ut-skill-active', function() {
            
            if( $(this).data('animateonce') === 'no' ) {
                                    
                $(this).removeClass("ut-already-visible").css('width',0);
                
            }
                        
        });                          
        
    });
    
    
    /* Gallery Slider
    ================================================== */
    $(document).on('click', '.ut-next-gallery-slide', function(event) {
        
        $('#' + $(this).data('for') ).trigger('next.owl.carousel');
        
        event.stopImmediatePropagation();
        event.preventDefault();
        
    });
   
    $(document).on('click', '.ut-prev-gallery-slide', function(event) {
    
        $('#' + $(this).data('for') ).trigger('prev.owl.carousel');
        
        event.stopImmediatePropagation();
        event.preventDefault();
        
    });
    
    /* Progress Circles 
    ================================================== */
    $('.bkly-progress-svg').appear();
        
    $(document.body).on('appear', '.bkly-progress-svg', function() {
        
        var $this = $(this);
        
        if( $this.hasClass('ut-animation-complete') ) {
            return;
        }
                                
        var totalProgress = $this.find('.circle').attr('stroke-dasharray'),
            progress      = $this.parent().data('circle-percent');
        
        $this.find('.stroke').get(0).style['stroke-dashoffset'] = totalProgress * progress / 100;
        
                       
    });
    
    $(document.body).on('disappear', '.bkly-progress-svg', function() {
        
        var $this  = $(this);
                        
        if( $this.data('animateonce') === 'no' ) {
            
            $this.find('.stroke').get(0).style['stroke-dashoffset'] = 0;
        
        } else {
            
            $this.addClass('ut-animation-complete');
        
        }
                        
    }); 
    
    
    /* Count To
    ================================================== */
    $.fn.countTo = function (options) {
        
        options = options || {};
        
        return $(this).each(function () {
            // set options for current element
            var settings = $.extend({}, $.fn.countTo.defaults, {
                from:            $(this).data('from'),
                to:              $(this).data('to'),
                speed:           $(this).data('speed'),
                refreshInterval: $(this).data('refresh-interval'),
                decimals:        $(this).data('decimals')
            }, options);
            
            // how many times to update the value, and how much to increment the value on each update
            var loops = Math.ceil(settings.speed / settings.refreshInterval),
                increment = (settings.to - settings.from) / loops;
            
            // references & variables that will change with each update
            var self = this,
                $self = $(this),
                loopCount = 0,
                value = settings.from,
                data = $self.data('countTo') || {};
            
            $self.data('countTo', data);
            
            // if an existing interval can be found, clear it first
            if (data.interval) {
                clearInterval(data.interval);
            }
            data.interval = setInterval(updateTimer, settings.refreshInterval);
            
            // initialize the element with the starting value
            render(value);
            
            function updateTimer() {
                value += increment;
                loopCount++;
                
                render(value);
                
                if (typeof(settings.onUpdate) == 'function') {
                    settings.onUpdate.call(self, value);
                }
                
                if (loopCount >= loops) {
                    // remove the interval
                    $self.removeData('countTo');
                    clearInterval(data.interval);
                    value = settings.to;
                    
                    if (typeof(settings.onComplete) == 'function') {
                        settings.onComplete.call(self, value);
                    }
                }
            }
            
            function render(value) {
                var formattedValue = settings.formatter.call(self, value, settings);
                $self.html(formattedValue);
            }
        });
    };
    
    $.fn.countTo.defaults = {
        from: 0,               // the number the element should start at
        to: 0,                 // the number the element should end at
        speed: 1000,           // how long it should take to count between the target numbers
        refreshInterval: 100,  // how often the element should be updated
        decimals: 0,           // the number of decimal places to show
        formatter: formatter,  // handler for formatting the value before rendering
        onUpdate: null,        // callback method for every time the element is updated
        onComplete: null       // callback method for when the element finishes updating
    };
    
    function formatter(value, settings) {
        return value.toFixed(settings.decimals);
    }

})(jQuery);
 /* ]]> */